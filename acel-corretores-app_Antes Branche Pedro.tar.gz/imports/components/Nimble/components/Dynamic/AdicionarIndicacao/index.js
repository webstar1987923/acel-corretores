import React, { Component } from 'react';
import { connect } from 'react-redux';
import { next, replace } from '../../../../../redux/modules/nimble';
import cep from 'cep-promise';

const { Date, Select } = Mongoloid.Components;

const ValidationSchema = new SimpleSchema({
  nome: {
    type: String,
    min: 2,
    max: 150,
    optional: true,
  },
  nascimento: {
    type: String,
    min: 2,
    max: 150,
    optional: true,
  },
  sexo: {
    type: String,
    optional: true,
  },
  estadoCivil: {
    type: String,
    optional: true,
  },
  CPF: {
    type: String,
    regEx: Regex.CPF,
    optional: true,
  },
  RG: {
    type: String,
    optional: true,
  },
  dataEmissaoRG: {
    type: String,
    optional: true,
  },
  orgaoEmissorRG: {
    type: String,
    optional: true,
  },
  CNH: {
    type: String,
    optional: true,
  },
  validadeCNH: {
    type: String,
    optional: true,
  },
  primeiraHabilitacao: {
    type: String,
    optional: true,
  },
  CEP: {
    type: String,
    regEx: Regex.CEP,
    optional: true,
  },
  logradouro: {
    type: String,
    min: 2,
    max: 200,
    optional: true,
  },
  numero: {
    type: String,
    min: 1,
    max: 10,
    optional: true,
  },
  complemento: {
    type: String,
    min: 1,
    max: 200,
    optional: true,
  },
  bairro: {
    type: String,
    min: 1,
    max: 200,
    optional: true,
  },
  cidade: {
    type: String,
    min: 1,
    max: 200,
    optional: true,
  },
  UF: {
    type: String,
    regEx: /[A-Z]{2}/,
    optional: true,
  },
  empresa: {
    type: String,
    optional: true,
  },
  profissao: {
    type: String,
    optional: true,
  },
  telefoneComercial: {
    type: String,
    regEx: Regex.telefone,
    optional: true,
  },
  telefoneResidencial: {
    type: String,
    regEx: Regex.telefone,
    optional: true,
  },
  ramal: {
    type: String,
    optional: true,
  },
  celular: {
    type: String,
    regEx: Regex.celular,
    optional: true,
  },
  email: {
    type: String,
    regEx: Regex.Email,
    optional: true,
  },
});

class _Component extends Component {
  
  constructor(props) {
    super(props);
    const mongoloidOptions = {
      self: this,
      mongoloidStateKey: 'AdicionarIndicacao',
      schema: ValidationSchema,
      opType: 'nimble',
    };
    Mongoloid(mongoloidOptions);
    this.handleChangeCEP = this.handleChangeCEP.bind(this);
    this._handleEnd = this._handleEnd.bind(this);
  }
  
  _handleEnd() {
    this.props.replace('checkout');
  }
  
  handleChangeCEP(event) {
    const cepValue = event.target.value;
    if (Regex.CEP.test(cepValue) == true) {
      cep(cepValue).then((address) => {
        console.log("CEP: ", address);
        if (address.cep) {
          this._setMongoloidValue({"UF": address.state}, event.target);
          this._setMongoloidValue({"cidade": address.city}, event.target);
          this._setMongoloidValue({"logradouro": address.street}, event.target);
          this._setMongoloidValue({"bairro": address.neighborhood}, event.target);
        }
      });
      this._handleChange(event, "CEP");
    }
  }
  
  render() {
    const {
      nome,
      timeDeFutebol,
      telefone,
      nascimento,
      sexo,
      estadoCivil,
      CPF,
      RG,
      dataEmissaoRG,
      orgaoEmissorRG,
      CNH,
      validadeCNH,
      primeiraHabilitacao,
      CEP,
      logradouro,
      numero,
      complemento,
      bairro,
      cidade,
      UF,
      empresa,
      profissao,
      telefoneComercial,
      telefoneResidencial,
      ramal,
      celular,
      email,
    } = this.state;
    return (
      <div className="adicionar-condutores-wrapper">
        <div className="row card condutores-card">
          <div id="form111" className="nimble-acel col-sm-3 col-md-3 animate-transition-2 concluido">
            <div className="tile purple">
              <div className="icons">
                <img id="form381-img" src="/icones/usuario/usuario_condutor_add_b_480.png" className="img-card" />
                <span className="span-t span-b">Adicionar Indicações</span>
              </div>
            </div>
          </div>
          <div className="nimble-acel col-sm-3 animate-transition-2 col-md-7 active">
            <div id="tile4" className="tile carros purple">
              <div className="icons hidden">
                <img id="form251-img" src="/icones/usuario/noun_574395_cc_03_p.png" className="img-card" />
                <span className="span-t span-b">Indicações do cliente</span>
              </div>
              <div className="form-group col-md-12">
                <img className="icon-p" src="/icones/usuario/noun_574395_cc_03_b.png" /><p>Indicações do cliente</p>
                <label className="col-md-6">
                  <span>Nome:</span>
                  <input type="text" name="nome" onChange={this._handleChange} value={nome} />
                </label>
                <label className="col-md-6">
                  <span>Telefone:</span>
                  <input type="text" name="telefone" onChange={this._handleChange} value={telefone} />
                </label>
                <label className="col-md-6">
                  <span>Profissão:</span>
                  <input type="text" name="profissao" onChange={this._handleChange} value={profissao} />
                </label>
                <label className="col-md-6">
                  <span>Estado Civil:</span>
                  <input type="text" name="estadoCivil" onChange={this._handleChange} value={estadoCivil} />
                </label>
                <label className="f col-md-6">
                  <span>Tem Filhos:</span>
                  <label className="radio-inline control-label">
                    <input type="radio"
                           name="quest2"
                           onChange={this._handleChange}
                           value={'sim'}/>
                    Sim
                  </label>
                  <label className="radio-inline control-label">
                    <input type="radio" name="quest2" onChange={this._handleChange} />
                    Não
                  </label>
                  <label className="qtdn-f hidden">
                    <select>
                      <option>Qtd</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                    </select>
                  </label>
                </label>
                <label className="col-md-6">
                  <span>Possui Veículos:</span>
                  <label className="radio-inline control-label">
                    <input type="radio"name="quest3" defaultValue="sim" onChange={this._handleChange} />
                    Sim
                  </label>
                  <label className="radio-inline control-label">
                    <input type="radio"name="quest3" defaultValue="não" onChange={this._handleChange} />
                    Não
                  </label>
                  <label className="qtdn-v hidden">
                    <select>
                      <option>Qtd</option>
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                    </select>
                  </label>
                </label>
                <label className="col-md-6">
                  <span>Time de futebol:</span>
                  <input type="text" name="timeDeFutebol" onChange={this._handleChange} value={timeDeFutebol} />
                </label>
                <label className="col-md-6">
                  <span>Bairro:</span>
                  <input type="text" name="bairro" onChange={this._handleChange} value={bairro} />
                </label>
                <label className="col-md-12">
                  <span>Anotações:</span>
                  <textarea className="col-md-12 anot-ind" />
                </label>
                <label className="col-md-6">
                  <span>Agendar:</span>
                  <input type="date" />
                </label>
                <label className="col-md-6">
                  <span>Produto:</span>
                  <select>
                    <option>Auto</option>
                    <option>Carro Fácil</option>
                    <option>Alarme</option>
                  </select>
                </label>
                <div className="col-md-12">
                  <button type="button"
                          className="btn btn-primary pull-left"
                          style={{ background: '#525252', border: 'none' }}
                          onClick={this._handleEnd}>
                    Ignorar
                  </button>
                  <button type="button" className="btn btn-primary pull-right" onClick={this.handleSubmit}>
                    Adicionar
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const ContainedComponent = GLOBAL.createContainer(props => props, _Component);

export default connect(state => state.nimble, { next, replace })(ContainedComponent);
