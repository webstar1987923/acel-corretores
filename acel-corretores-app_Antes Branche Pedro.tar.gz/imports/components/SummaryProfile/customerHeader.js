import React, { Component, PropTypes } from 'react';
import { createContainer } from 'meteor/react-meteor-data';
import ModalClassify from './classify';
import ModalAnnotations from './annotations';

class CustomerHeader extends Component {

  constructor(props) {
    super(props);
  }

  completeProfile() {
    const custDoc = {
      customerId: this.props.custDoc._id
      // productName: this.props.params.productName,
    };

    Session.set('customerDoc', custDoc);
    Router.push('/complete-profile');
  }

  render() {
    const { loading, custDoc = {}} = this.props;

    if (loading) {
      return (
        <div className="navbar-venda loading"/>
      );
    }

    return (
      <div className="navbar-venda">
        <div className="navbar-venda-lead">
          <img src="/img/lead.jpg"/>
          <div className="info-main">
            <span>Cliente</span>
            <p>{custDoc.name}</p>
          </div>
          <div>
            <button type="button" onClick={() => this.completeProfile()}
                    className="btn btn-classificar pull-left btn-perfil-completo">
              Perfil completo
            </button>

            <div className="telefone">
              <label htmlFor="sel1">Telefone:</label>
              <select className="form-control" id="sel1">
                <option>{custDoc.mobilePhone}</option>
                <option>{custDoc.homePhone}</option>
                <option>{custDoc.workPhone}</option>
              </select>
            </div>
            <p><span>Email:</span> {custDoc.homeEmail}</p>
          </div>
          <div class="div-btn-cotacao">
            <ModalAnnotations customerId={this.props.customerId} productName={this.props.productName}/>
            <ModalClassify customerId={this.props.customerId} productName={this.props.productName}/>
          </div>

        </div>

        <div className="pull-right navbar-venda-produto">
          <i title="Auto" className="fa fa-car" aria-hidden="true"></i>
          <div className="info-main">
            <span>Ofertando</span>
            <p>Carro fácil</p>
          </div>
        </div>

      </div>
    );
  }

}

export default createContainer((props) => {
  const customersHandle = Meteor.subscribe('customers.all');

  // if (!props.customerId) return {};

  let custId;

  //-------------------------------------
  // Comes from Summary profile
  //-------------------------------------
  if (props.customerId) {
    custId = props.customerId;
  } else {
    //-------------------------------------
    // Comes from Nimble
    //-------------------------------------
    const objCust = Session.get('currentQuotation') || {};
    custId = objCust.customerId;
  }

  const custDoc = (custId) ? Customers.findOne({ _id: custId }) : {};

  return {
    custDoc,
    loading: !customersHandle.ready(),
    user: Meteor.user(),

    profile: (Meteor.user() || {}).profile || {},
    facebookProfile: (((Meteor.user() || {}).services || {}).facebook) || {},

  };
}, CustomerHeader);
