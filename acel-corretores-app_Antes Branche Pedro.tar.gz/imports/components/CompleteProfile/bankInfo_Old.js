import React from 'react';
import { createContainer } from 'meteor/react-meteor-data';

class BankInfo extends React.Component {

  editarConjuge(){
    $('.contenedor-formulario--view--familiares__conjuge').addClass('hidden');
    $('.contenedor-formulario--familiares__conjuge').removeClass('hidden');
  }

  visualizarConjuge(){
    $('.contenedor-formulario--view--familiares__conjuge').removeClass('hidden');
    $('.contenedor-formulario--familiares__conjuge').addClass('hidden');
    $('.contenedor-formulario--firstquestion--conjuge').addClass('hidden');
  }

  render() {

    if (this.props.loading) return <div className="div-content col-md-12 loading"></div>;

    return (

      <div className="tab-pane fade" id="bancarias">

        <div className="contenedor-formulario contenedor-formulario--view contenedor-formulario--view--familiares__conjuge">
          <div className="formulario">
            <div className="formgroup-info">
              <button className="fa fa-pencil btn btn-editar" onClick={() => this.editarConjuge()}></button>
              <div className="row">

                <div className="col-md-3">
                  <div className="input-group">
                    <span className="label">Banco:</span>
                    <p>Bradesco</p>
                  </div>
                </div>

                <div className="col-md-3">
                  <div className="input-group">
                    <span className="label">Agência:</span>
                    <p>0000</p>
                  </div>
                </div>

                <div className="col-md-3">
                  <div className="input-group">
                    <span className="label">Conta:</span>
                    <p>0000-0</p>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </div>

        <div className="contenedor-formulario contenedor-formulario--familiares__conjuge hidden">
          <div className="formulario">
            <div className="formgroup-info formgroup-info--editavel">
              <div className="row">

                <div className="col-md-3">
                  <div className="input-group">
                    <label className="label" for="cj">Banco:</label>
                    <input type="text" value="0000" />
                  </div>
                </div>

                <div className="col-md-3">
                  <div className="input-group">
                    <label className="label" for="dt-nasc">Agência:</label>
                    <input type="text" value="0000-0" />
                  </div>
                </div>

                <div className="col-md-3">
                  <div className="input-group">
                    <label className="label" for="sexo-conjugue">Conta:</label>
                    <input type="text" value="00000" />
                  </div>
                </div>

              </div>

              <div className="row">
                <button className="btn pull-right btn-padrao" onClick={() => this.visualizarConjuge()}>Salvar</button>
                <button className="btn pull-right btn-padrao btn-secundario">Cancelar</button>
              </div>
            </div>


          </div>
        </div>

      </div>

    )
  }


}

export default createContainer((props) => {

  const customersHandle = Meteor.subscribe('customers.all');
  const custDoc = Customers.findOne({ _id: props.customerId });

  return {
    custDoc,
    loading: !customersHandle.ready(),
    user: Meteor.user(),
  };
}, BankInfo);
