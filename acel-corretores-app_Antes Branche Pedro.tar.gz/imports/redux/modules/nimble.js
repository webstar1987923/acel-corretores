import uniqBy from 'lodash.uniqby';

const INIT = 'nimble/INIT';
const NEXT = 'nimble/NEXT';
const GOTO_FORM = 'nimble/GOTO_FORM';
const GOTO_COMPONENT = 'nimble/GOTO_COMPONENT';
const BACK = 'nimble/BACK';
const GOOD = 'nimble/GOOD';
const BAD = 'nimble/BAD';
const SUBMIT = 'nimble/SUBMIT';
const SET_VALUE = 'nimble/SET_VALUE';
const SET_ARGS_PATH = 'nimble/SET_ARGS_PATH';
const REMOVE_ARGS_FROM_CALLER = 'nimble/REMOVE_ARGS_FROM_CALLER';
const SUBMIT_VOTO = 'nimble/SUBMIT_VOTO';
const REPLACE = 'nimble/REPLACE';
const SET_LOCAL_COMPONENT_STATE = 'nimble/SET_LOCAL_COMPONENT_STATE';
const SET_QUOT_DATA = 'nimble/SET_QUOT_DATA';

global.LocalArgumentsCollecion = getDB('nimble.arguments');

function activeSteps(state, action) {
  const { idToGo, argumentos, caller } = action;
  const responseTo = caller;
  const stepToAdd = state.steps.find(step =>
    // console.log(step.id, id, step, state.steps);
  step.id == idToGo);

  if (!stepToAdd) {
    console.warn(
      `${idToGo} não encontrou resultados em ${JSON.stringify(
        state.steps,
        null,
        2,
      )}`,
    );
  }

  const activeSteps = state.activeSteps.filter(
    step => step.responseTo !== responseTo,
  );

  // console.log({stepToAdd, id, action});

  return [...activeSteps, { ...stepToAdd, responseTo }];
  // return uniqBy([...activeSteps, {...stepToAdd, responseTo}], 'responseTo');
}

const initialState = {
  steps: [],
  currentStepID: '',
  stepsHistory: [],
  activeSteps: [],
  initialStepID: localStorage.getItem('initialStepID') || 'possuiVeiculo',
  currentArgumentos: [],
  values: {},
  localComponentStates: {},
  argumentoFeedbacks: [],
  currentCustomer: {},
  produto: null
};

export default function reducer(state = initialState, action = {}) {
  let currentStepID;

  switch (action.type) {
    case SET_VALUE: {
      return {
        ...state,
        values: { ...state.values, ...action.payload },
        currentArgumentos: action.currentArgumentos || state.currentArgumentos,
      };
    }

    case SET_LOCAL_COMPONENT_STATE: {
      return {
        ...state,
        localComponentStates: { ...state.localComponentStates, ...action.payload },
      };
    }

    case SUBMIT_VOTO: {
      return {
        ...state,
        argumentoFeedbacks: uniqBy(
          [
            ...state.argumentoFeedbacks,
            {
              ...action.payload,
              ...action.step,
            },
          ],
          'feedbackID',
        ),
      };
    }

    case SET_ARGS_PATH: {
      return {
        ...state,
        currentArgumentos: action.payload,
        path: action.path
      };
    }

    case REMOVE_ARGS_FROM_CALLER: {
      return {
        ...state,
        currentArgumentos: []
      };
    }

    case INIT: {
      const steps = action.steps || [];
      const step = steps.find(f => f.id == state.initialStepID);

      return {
        ...state,
        currentStepID: state.initialStepID,
        stepsHistory: [step],
        activeSteps: [step],
        steps,
      };
    }

    case GOTO_FORM: {
      const steps = state.steps;
      const { idToGo, argumentos } = action;
      const step = steps.find(f => f.id == idToGo);

      return {
        ...state,
        currentStepID: idToGo,
        stepsHistory: [...state.stepsHistory, step],
        activeSteps: activeSteps(state, action),
        currentArgumentos: argumentos || state.currentArgumentos,
      };
    }

    case GOTO_COMPONENT: {
      const steps = state.steps;
      const { caller = {} } = action;
      const { argumentos, idToGo } = caller;
      const stepToAdd = steps.find(s => s.id == idToGo);

      if (!stepToAdd) {
        console.warn('404', step);
        return state;
      }

      return {
        ...state,
        currentStepID: idToGo,
        stepsHistory: [...state.stepsHistory, stepToAdd],
        activeSteps: [
          ...state.activeSteps,
          { ...stepToAdd, responseTo: caller.idToGo },
        ],
        currentArgumentos: argumentos || state.currentArgumentos,
      };
    }

    case GOOD:
      feedbacks = uniqBy(
        [
          ...state.feedbacks,
          {
            name: action.name,
            question: action.question,
            feedback: 'good',
            argumento: action.argumento,
          },
        ],
        'argumento',
      );

      return { ...state, feedbacks };

    case BAD:
      feedbacks = uniqBy(
        [
          ...state.feedbacks,
          {
            name: action.name,
            question: action.question,
            feedback: 'bad',
            argumento: action.argumento,
          },
        ],
        'argumento',
      );

      return { ...state, feedbacks };

    case SUBMIT:
      currentStepID = state.currentStepID;
      if (currentStepID >= 1) return state;
      return { ...state, currentStepID: currentStepID - 1 };

    case REPLACE:
      return { ...state, currentStepID: action.id };

    case SET_QUOT_DATA:
      return {
        ...state,
        currentCustomer: action.currentCustomer,
        produto: action.produto
      };

    default:
      return state;
  }
}

export const init = (steps, forceRestart) => (dispatch, getState) => {
  const { activeSteps, initial } = getState().nimble;

  if (!forceRestart && activeSteps.length) return;

  dispatch({
    type: INIT,
    steps,
    forceRestart,
    caller: 'init',
  });
};

export const setArgumentosPath = (payload = {}) => (dispatch, getState) => {
  const { nextProps = {} } = payload;
  let { name : caller, value } = nextProps;
  const { values } = getState().nimble;
  const keys = Object.keys(values || {});

  const reduceKeys = (prev, key) => {
    const currentValuesObj = values[key];
    if (Object.keys(currentValuesObj).length > 1) {
      return prev; // é um form com varios campos, não é do tipo select, por ex.
    }
    return prev.concat(`${key}:${currentValuesObj[key]}__`);
  };

  console.log({caller, value});

  let args = Argumentacoes.find({
    $or: [
      { parentName: `generic` },
      {questionId: caller, responseValue: value}
    ]
  }).fetch();

  dispatch({
    type: SET_ARGS_PATH,
    payload: args
  });
};

export const goToForm = (step, name, value) => {
  const { responses, id: caller, question } = step;

  let response;
  if (responses.length > 1 && value) {
    response = responses.find((res) => {
      const matches = value.match(res.regex);
      return matches;
    });
  } else {
    response = responses[0];
  }

  const { goto, argumentos, regex } = response;

  return ({
    type: GOTO_FORM,
    idToGo: goto,
    argumentos,
    caller,
    question,
    regex,
  });
};

export const replace = id => ({
  type: REPLACE,
  id,
});

export const goToComponent = caller => ({
  type: GOTO_COMPONENT,
  caller,
});

export const setValue = (step, name, value) => (dispatch, getState) => {
  const state = getState().nimble;
  const id = step.id;
  const previousValue = state.values[id] || {};

  let payload;


  if (typeof value === 'object') {
    payload = {
      ...state.values,
      [id]: {
        ...previousValue,
        ...value,
      }
    };
  } else {
    payload = {
      ...state.values,
      [id]: {
        ...previousValue,
        [name]: value,
      }
    };
  }

  dispatch({
    type: SET_VALUE,
    payload,
    step,
  });
};

export const localComponentStates = (step, localAppState) => (dispatch, getState) => {
  const oldStates = getState().nimble.localComponentStates;

  const payload = {
    ...oldStates,
    [step.id]: localAppState
  };

  dispatch({
    type: SET_LOCAL_COMPONENT_STATE,
    payload
  });
};

export const next = (nextProps, localAppState) => (dispatch, getState) => {
  const { name, value, step, component } = nextProps;
  if (component) return dispatch(goToComponent(nextProps));

  dispatch(setValue(step, name, value));
  dispatch(goToForm(step, name, value));
  dispatch(setArgumentosPath({ nextProps, localAppState }));
  if (localAppState) localComponentStates(step, localAppState)(dispatch, getState);
};

export const handleGood = (name, question, argumento) => ({
  type: GOOD,
  name,
  question,
  argumento,
});

export const handleBad = (name, question, argumento) => ({
  type: BAD,
  name,
  question,
  argumento,
});

export const handleSubmit = (name, question, value) => ({
  type: SUBMIT,
  name,
  question,
  value,
});

export const handleSubmitVoto = (step, payload) => ({
  type: SUBMIT_VOTO,
  step,
  payload: { ...payload, feedbackID: `${step.id}__${payload.argumento}` },
});

export const setQuotData = payload => {
  return {
    type: SET_QUOT_DATA,
    currentCustomer: payload.currentCustomer,
    produto: payload.produto
  };
};
