import defaultsDeep from 'lodash.defaultsdeep';

// function convertCustomerToNimbleFields(key, value) {
//   const customerDemo = {
//     "_id": "eSQqe9AbEQZjixWfP",
//     "code": 90028,
//     "name": "Nils Klocko",
//     "document": 24809,
//     "gender": "Feminino",
//     "birthday": "2017-01-21T16:08:53.256Z",
//     "website": "mauricio.biz",
//     "mobilePhone": "206.485.6275 x83281",
//     "homeEmail": "Lorna.Brekke57@gmail.com",
//     "homePhone": "638.055.2698 x6502",
//     "homeAddress": "414 Erdman Court",
//     "homeZipcode": "65220-0703",
//     "homeCity": "Demariostad",
//     "homeState": "Arkansas",
//     "homeCountry": "Azerbaijan",
//     "company": "Bosco, Dicki and Prohaska",
//     "position": "aut quis dolores",
//     "workEmail": "Lennie62@gmail.com",
//     "workPhone": "137.650.5352 x809",
//     "workAddress": "15478 Cummings Falls",
//     "workZipcode": "30212-8201",
//     "workCity": "New Gladys",
//     "workState": "Mississippi",
//     "workCountry": "Andorra",
//     "originId": "soci",
//     "brokerId": null,
//     "children": [
//       {
//         "name": "Hipolito Hamill",
//         "age": 48362
//       }
//     ],
//     "maritalStatus": "Casado",
//     "pet": "Não",
//     "mobileOperator": "tempora",
//     "income": "R$ 535.00"
//   };
//
//   /**
//    "code",
//    "name",
//    "document",
//    "gender",
//    "birthday",
//    "website",
//    "mobilePhone",
//    "homeEmail",
//    "homePhone",
//    "homeAddress",
//    "homeZipcode",
//    "homeCity",
//    "homeState",
//    "homeCountry",
//    "company",
//    "position",
//    "workEmail",
//    "workPhone",
//    "workAddress",
//    "workZipcode",
//    "workCity",
//    "workState",
//    "workCountry",
//    "originId",
//    "brokerId",
//    "children",
//    "maritalStatus",
//    "pet",
//    "mobileOperator",
//    "income"
//    */
//   switch (key){
//     case '_id': return ['_id', value];
//     case 'code': return ['code', value];
//     case 'document': return ['CPF', value];
//     case 'gender': return ['sexo', value];
//   }
// }

function upsertQuote(data) {
  const {
    _id,
    customerId,
    brokerId,
    productName
  } = data;

  const existente = Quotations.findOne({
      $or: [
        { _id },
        { customerId, brokerId, productName }
      ]
    }) || {};

  let createdId;
  let updatedId;

  if (existente._id) {
    const newData = defaultsDeep(existente, data);
    Quotations.update(existente._id, newData);
    updatedId = existente._id;
  } else {
    const nextQuoteNum = Meteor.call('quotations.getNextQuoteNum');

    createdId = Quotations.insert({
      nextQuoteNum,
      ...data
    });
  }

  return { createdId, updatedId };
}


function updateUserDataFromNimble(data) {
  const {
    _id,
    customerId,
    brokerId,
    productName,
    upsertResult,
    reduxNimbleData
  } = data;

  return data;
}


Meteor.methods({
  //TODO': handle auth
  /**
   * @returns {{userDataUpdatedFromNimble: {}, upsertQuoteResult: {createdId, updatedId}}}
   */
  'nimble.upsertQuote'(data) {
    const { reduxNimbleData } = data;

    const upsertQuoteResult = upsertQuote(data);

    let userDataUpdatedFromNimble = {};
    if (typeof reduxNimbleData === 'object')
      userDataUpdatedFromNimble = updateUserDataFromNimble(data, upsertQuoteResult, reduxNimbleData);

    return {
      userDataUpdatedFromNimble,
      upsertQuoteResult
    }
  }
});
