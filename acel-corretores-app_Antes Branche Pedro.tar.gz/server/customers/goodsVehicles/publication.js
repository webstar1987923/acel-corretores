Meteor.publish(

  'goodsVehicles.all', () => (GoodsVehicles.find({})),

);
