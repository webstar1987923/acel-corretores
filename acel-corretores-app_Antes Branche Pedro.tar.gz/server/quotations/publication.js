Meteor.publish(

	'quotations.all', () => (Quotations.find({})),

);
