Meteor.publish(

  'prodArguments.all', () => (ProdArguments.find({})),

);
