Meteor.publish(

  'statusPhase.all', () => (StatusPhase.find({})),

);
